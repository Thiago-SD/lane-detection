#include <iostream>
#include <fstream>
#include <string>
#include <iomanip> 

#include <carmen/carmen.h>
#include <carmen/localize_ackerman_interface.h>

/*
typedef struct {
  carmen_point_t globalpos, globalpos_std, odometrypos;
  carmen_pose_3D_t pose;
  carmen_vector_3D_t velocity;
  double v, phi;
  double globalpos_xy_cov;
  int converged;
  int semi_trailer_engaged;
  int semi_trailer_type;
  int num_trailers;
  double trailer_theta[MAX_NUM_TRAILERS];
  double timestamp;
  char *host;
} carmen_localize_ackerman_globalpos_message;
*/

std::string file_path;

void carmen_globalpos_saver_print_msg(carmen_localize_ackerman_globalpos_message* msg)
{
	std::cout << "globalpos.x: " << msg->globalpos.x << std::endl;
	std::cout << "globalpos.y: " << msg->globalpos.x << std::endl;
	std::cout << "globalpos.theta: " << msg->globalpos.x << std::endl;


}

carmen_localize_ackerman_globalpos_message* carmen_globalpos_saver_read_globalpos_from_file(const char* path)
{
	std::ifstream arquivo(path);
	carmen_localize_ackerman_globalpos_message* msg = (carmen_localize_ackerman_globalpos_message*) malloc(sizeof(carmen_localize_ackerman_globalpos_message));

	if (arquivo.is_open()) {  // Verifica se o arquivo foi aberto com sucesso
        std::string linha;
        while (std::getline(arquivo, linha)) {  // Lê linha por linha
            if(linha == "msg_begin")
			{
				std::getline(arquivo, linha);
				msg->globalpos.x = std::stod(linha);

				std::getline(arquivo, linha);
				msg->globalpos.y = std::stod(linha);

				std::getline(arquivo, linha);
				msg->globalpos.theta = std::stod(linha);

				std::getline(arquivo, linha);
				msg->globalpos_std.x = std::stod(linha);

				std::getline(arquivo, linha);
				msg->globalpos_std.y = std::stod(linha);

				std::getline(arquivo, linha);
				msg->globalpos_std.theta = std::stod(linha);

				std::getline(arquivo, linha);
				msg->odometrypos.x = std::stod(linha);

				std::getline(arquivo, linha);
				msg->odometrypos.y = std::stod(linha);

				std::getline(arquivo, linha);
				msg->odometrypos.theta = std::stod(linha);

				std::getline(arquivo, linha);
				msg->timestamp = std::stod(linha);
				
			}
        }

        arquivo.close();  // Fecha o arquivo
    } else {
        std::cerr << "Erro ao abrir o arquivo!" << std::endl;
    }
	return msg;
}

//////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////
//																								//
// Handlers																						//
//																								//
//////////////////////////////////////////////////////////////////////////////////////////////////

void
carmen_globalpos_saver_globalpos_handler(carmen_localize_ackerman_globalpos_message *globalpos_msg)
{
	std::ofstream arquivo(file_path, std::ios::app); 
	if (arquivo.is_open()) {  // Verifica se o arquivo foi aberto com 
	 	arquivo << "msg_begin\n";

		arquivo << globalpos_msg->globalpos.x << '\n';
		arquivo << globalpos_msg->globalpos.y << '\n';
		arquivo << globalpos_msg->globalpos.theta << '\n';
		arquivo << globalpos_msg->globalpos_std.x << '\n';
		arquivo << globalpos_msg->globalpos_std.y << '\n';
		arquivo << globalpos_msg->globalpos_std.theta << '\n';
		arquivo << globalpos_msg->odometrypos.x << '\n';
		arquivo << globalpos_msg->odometrypos.y << '\n';
		arquivo << globalpos_msg->odometrypos.theta << '\n';
		arquivo << std::fixed << std::setprecision(5) << globalpos_msg->timestamp << '\n';

		arquivo.close();
    } else {
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////
//																								//
// Inicializations																				//
//																								//
//////////////////////////////////////////////////////////////////////////////////////////////////

static void 
shutdown_module(int sig)
{
	(void) sig;

	static int done = 0;

	if (!done)
	{
		carmen_ipc_disconnect();
		printf("globalpos_saver disconnected from IPC.\n");
		fflush(stdout);
	}

	exit(0);
}


static void
define_messages()
{
		carmen_localize_ackerman_subscribe_globalpos_message(NULL,
									(carmen_handler_t)carmen_globalpos_saver_globalpos_handler,
									CARMEN_SUBSCRIBE_LATEST);
}


static void 
read_parameters(int argc, char *argv[])
{
	if (argc < 2)
	{
		printf("Use %s <file_path>\n", argv[0]);
		exit(-1);
	}

	file_path = std::string(argv[1]);
	std::ofstream arquivo(file_path, std::ios::trunc);
	arquivo.close();
}

int 
main(int argc, char **argv)
{
    
	signal(SIGINT, shutdown_module);

	carmen_ipc_initialize(argc, argv);
	carmen_param_check_version(argv[0]);
	read_parameters(argc, argv);
    define_messages();

	carmen_ipc_dispatch();
    return 0;
}
